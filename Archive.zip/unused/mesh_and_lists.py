#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 17:26:50 2022

@author: bogdan
"""

def make_mesh_data(p,t):
    
    nt = p.shape[1]