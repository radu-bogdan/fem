
# import numpy as np


# 

def kek(a,b):
    return a,b


a,b = kek(1,2)
a,b += kek(1,2)
