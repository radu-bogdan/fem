import plotly.graph_objects as go
import numpy as np
np.random.seed(1)

N = 70

fig = go.Figure()

fig.add_trace(go.Mesh3d(
                    x=(70*np.random.randn(N)),
                    y=(55*np.random.randn(N)),
                    z=(40*np.random.randn(N)),
                    opacity=0.5,
                    color='rgba(244,22,100,0.6)'
                  ))

fig.update_layout(
    scene = dict(
        xaxis = dict(nticks=4, range=[-100,100],),
        yaxis = dict(nticks=4, range=[-50,200],),
        zaxis = dict(nticks=4, range=[-100,100],),),
    # margin=dict(r=20, l=10, b=10, t=10)
    )

fig.show()