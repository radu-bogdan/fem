# -*- coding: utf-8 -*-

import numpy as np


def make_mesh_data(p,t):
    nt = t.shape[1]
    return nt
